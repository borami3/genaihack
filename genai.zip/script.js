function custom(file){

//send to server


}